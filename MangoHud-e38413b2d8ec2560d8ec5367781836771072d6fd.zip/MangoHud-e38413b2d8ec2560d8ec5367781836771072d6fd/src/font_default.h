#pragma once
#ifndef MANGOHUD_FONT_DEFAULT_H
#define MANGOHUD_FONT_DEFAULT_H

#ifdef __cplusplus
extern "C" {
#endif

const char* GetDefaultCompressedFontDataTTFBase85(void);

#ifdef __cplusplus
}
#endif

#endif // MANGOHUD_FONT_DEFAULT_H
