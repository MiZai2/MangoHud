#ifndef __D3D11_IMPL_H__
#define __D3D11_IMPL_H__

namespace impl
{
	namespace d3d11
	{
		void init();
	}
}


#endif // __D3D11_IMPL_H__